@extends('layout')
@section('title', "Home Page")
@section('content')
    {{auth()->user()->name}}
    {{auth()->user()->email}}
    <br>Kindly check the details and make the changes as required getting back into reigistration form
@endsection
