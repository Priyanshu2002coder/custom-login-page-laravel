<?php $__env->startSection('title', "Home Page"); ?>
<?php $__env->startSection('content'); ?>
    <?php echo e(auth()->user()->name); ?>

    <?php echo e(auth()->user()->email); ?>

    <br>Kindly check the details and make the changes as required getting back into reigistration form
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\custom-auth-laravel\custom_login\resources\views/welcome.blade.php ENDPATH**/ ?>